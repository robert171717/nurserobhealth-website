---
name: daily-brief
description: Generate TERMINATOR 2 world-class tactical briefing — Executive Summary, Solana memecoin table (5M/1H/24H), Pump.fun strict-filtered launches, Polymarket w/ word-boundary categories, alpha signals, actionable trade ideas — auto-saved to /mnt/c/Users/Robert/Desktop/Daily Brief/
version: 13.2
author: NurseRobHealth
tags: [solana, polymarket, automation, productivity, terminator, cyberpunk, pumpfun]
related_skills: []
---

# Daily Brief - Skynet Override Raw Degen Edition v12.0 🚀💀

## Overview

Generate a cold, lethal TERMINATOR 2-style daily briefing combining:
- 🔥 **Live** Solana meme coins (prices, 24h % change, volume) from DexScreener with **STRICT SYMBOL VERIFICATION** - **EXACTLY 5 UNIQUE COINS GUARANTEED**
- ⚡ **PUMP.FUN TRENDING** - top 5 trending coins via **DIRECT API** with FULL METRICS: name, symbol, market cap (USD), momentum vs ATH (% change), participant count, and direct links! 🔴
- 💀 **LIVE** Polymarket prediction markets via Gamma API with `active=true` filter (LIVE markets only, sorted by 24h volume — auto-favors crypto/tech/politics)
- 📰 **SOLANA ECOSYSTEM INTELLIGENCE** - recent news and announcements via web_search
- 💾 Auto-saved to `/mnt/c/Users/Robert/Desktop/Daily Brief/DAILY-BRIEF.md` (HARD-CODED NATIVE WSL2 PATH)

## When to Use

- Initiating daily market reconnaissance operations
- Need consolidated crypto + prediction market intel
- Deploying TERMINATOR-style content for social ops
- Building automated tactical briefing workflows

## Prerequisites

```bash
# Python 3.8+ with urllib (built-in, no extra packages needed)
python3 --version
```

## Step-by-Step Instructions

### Run the Skynet Override Brief Generator

Execute this command to fetch live data:

```python
import json
import os
import re
import time
from datetime import datetime
import urllib.request

start_time = time.time()

print("🚀 SKYNET OVERRIDE INITIATED...")
print("⚡ Loading tactical briefing protocol v11.0...\n")

# === Hard-coded save path for native WSL2 ===
output_dir = "/mnt/c/Users/Robert/Desktop/Daily Brief"
os.makedirs(output_dir, exist_ok=True)

# === Helper functions ===
def safe_float(val, default=0.0):
    """Safely convert value to float, handling None and invalid types"""
    try:
        return float(val) if val is not None else default
    except:
        return default

def http_get(url, timeout=10):
    """Safe HTTP GET with error handling"""
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    })
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode())

def fmt_price(p):
    """Format price with appropriate precision"""
    if p < 0.00000001:
        return f"${p:.2e}"  # Scientific notation for tiny prices
    elif p < 0.000001:
        return f"${p:.8f}"
    elif p < 0.0001:
        return f"${p:.6f}"
    elif p < 0.01:
        return f"${p:.6f}"
    elif p < 1:
        return f"${p:.4f}"
    return f"${p:.2f}"

def fmt_change(c):
    """Format percentage change with directional indicator"""
    icon = "📈" if c > 0 else "📉" if c < 0 else "➡️"
    return f"{c:+.2f}% {icon}"

def fmt_momentum(m):
    """Format momentum vs ATH with contextual emoji"""
    if m > 10:
        return f"{m:+.1f}% 🚀"
    elif m > 0:
        return f"{m:+.1f}% 📈"
    elif m > -50:
        return f"{m:+.1f}% 📉"
    return f"{m:+.1f}% 💀"

# === 1. SOLANA MEME COINS - v12.0: Normalized symbol matching + volume sort ===
print("🔥 Fetching Solana meme coins...")

# Known token addresses for fallback verification (solana chain)
KNOWN_ADDRESSES = {
    'WIF': 'EKpQGSJtjMFqKZ9KQmSxmgm2jH9MTSCgEoJYMb8mvqVR',
    'BONK': 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
    'POPCAT': '7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHySLwLE',
    'MEW': 'MEW1gQWJ3nEXg2qgERiKu7FAFj79PHvQVREQUaspTaw',
    'GIGA': '63LfDmNb3MQ8mw9MtZ2To9bEA2M71kZUUGq5tiJxcqj9',
}

# v12.0: Alternative search queries for tokens where symbol search fails
# (DexScreener sometimes lists real tokens with $$ prefix e.g. $$WIF)
NAME_SEARCH_QUERIES = {
    'WIF': 'dogwifhat',
    # Add others here if symbol search fails for them too
}

meme_coins = [
    'WIF', 'BONK', 'POPCAT', 'MEW', 'GIGA', 'MYRO', 'SLERF',
    'ORCA', 'JUP', 'RAY', 'JTO', 'W', 'PYTH', 'ONDO', 'AERO'
]

solana_coins = []
seen_symbols = set()

def norm_sym(s):
    """Normalize symbol: strip leading $, uppercase, strip whitespace"""
    return s.lstrip('$').strip().upper()

for coin in meme_coins:
    if len(solana_coins) >= 5:
        break
    try:
        # v12.0: Collect pairs from symbol search
        data = http_get(f"https://api.dexscreener.com/latest/dex/search?q={coin}", timeout=8)
        all_pairs = [p for p in data.get('pairs', []) if p.get('chainId') == 'solana']
        
        # v12.0: For known problematic tokens, also run name search and merge results
        if coin in NAME_SEARCH_QUERIES:
            try:
                data2 = http_get(f"https://api.dexscreener.com/latest/dex/search?q={NAME_SEARCH_QUERIES[coin]}", timeout=8)
                extra_pairs = [p for p in data2.get('pairs', []) if p.get('chainId') == 'solana']
                all_pairs.extend(extra_pairs)
            except:
                pass
        
        # v12.0 FIX: Sort by 24h volume (descending) — pick the highest-volume pair
        all_pairs.sort(key=lambda x: safe_float((x.get('volume', {}) or {}).get('h24', 0)), reverse=True)
        
        # v12.0 FIX: Normalize symbols - strip leading $ before comparison
        matched = False
        for p in all_pairs:
            base = p.get('baseToken', {})
            symbol_raw = base.get('symbol', '')
            symbol = norm_sym(symbol_raw)
            address = base.get('address', '')
            
            # v12.0: Normalized symbol check
            if symbol != norm_sym(coin):
                continue
            if symbol in seen_symbols:
                continue
            
            vol = safe_float(p.get('volume', {}).get('h24', 0))
            if vol < 1000:
                continue  # Quality filter
            
            seen_symbols.add(symbol)
            solana_coins.append({
                'symbol': symbol,
                'price': safe_float(p.get('priceUsd', 0)),
                'change24h': safe_float(p.get('priceChange', {}).get('h24', 0)),
                'volume': vol,
                'address': address,
                'url': p.get('url', ''),
                'pairAddress': p.get('pairAddress', '')
            })
            matched = True
            break
            
    except Exception as e:
        print(f"  ⚠️ {coin}: {e}")

# Sort by volume (highest first) and take top 5
solana_coins.sort(key=lambda x: x['volume'], reverse=True)
solana_coins = solana_coins[:5]
print(f"  ✅ Solana: {len(solana_coins)} unique coins acquired")

# === 2. PUMP.FUN TRENDING - OPTIMIZED (v11.0) ===
print("🔴 Fetching Pump.fun trending...")

pumpfun_coins = []
try:
    data = http_get("https://frontend-api-v3.pump.fun/coins/currently-live", timeout=10)
    
    # Filter out banned coins and zero market cap
    valid = [c for c in data if not c.get('is_banned', False) and safe_float(c.get('usd_market_cap', 0)) > 0]
    valid.sort(key=lambda x: safe_float(x.get('usd_market_cap', 0)), reverse=True)
    
    for coin in valid[:10]:
        symbol = (coin.get('symbol') or '???').upper()
        if symbol in ['PUMP', 'FUN'] or len(symbol) < 2:
            continue
        
        usd_mcap = safe_float(coin.get('usd_market_cap', 0))
        ath_mcap = safe_float(coin.get('ath_market_cap', 0))
        total_supply = safe_float(coin.get('total_supply', 1))
        price = usd_mcap / total_supply if total_supply > 0 else 0
        
        # Performance vs ATH (momentum indicator)
        if ath_mcap > 0:
            perf_vs_ath = ((usd_mcap / ath_mcap) - 1) * 100
        else:
            perf_vs_ath = 0
        
        pumpfun_coins.append({
            'name': coin.get('name', 'Unknown'),
            'symbol': f"${symbol}",
            'price': price,
            'market_cap_usd': usd_mcap,
            'performance_vs_ath': perf_vs_ath,
            'participants': coin.get('num_participants', 0),
            'url': f"https://pump.fun/{coin.get('mint', '')}"
        })
        
        if len(pumpfun_coins) >= 5:
            break
    
    print(f"  ✅ Pump.fun: {len(pumpfun_coins)} trending coins")
except Exception as e:
    print(f"  ❌ Pump.fun: {e}")

# === 3. POLYMARKET - v12.0: Smart scoring + category diversification ===
print("💀 Fetching Polymarket...")

polymarkets = []
try:
    data = http_get("https://gamma-api.polymarket.com/markets?active=true&limit=100", timeout=10)
    
    # Filter: must be accepting orders AND active
    live = [m for m in data if m.get('acceptingOrders', False) and m.get('active', False)]
    
    # Sort by 24h volume (most active first)
    live.sort(key=lambda x: safe_float(x.get('volume24hrClob', 0) or x.get('volume24hr', 0) or 0), reverse=True)
    
    # v12.0: Scoring system for market relevance
    # +5 for crypto/tech/ai, +3 for politics/elections, +1 for sports, -10 for boring (world cup country spam)
    SCORE_RULES = [
        (['bitcoin', 'crypto', 'ethereum', 'solana', 'defi', 'nft', 'blockchain', 'token'], 5),
        (['ai', 'artificial intelligence', 'chatgpt', 'openai', 'llm', 'gpt'], 5),
        (['tech', 'apple', 'nvidia', 'tesla', 'spacex', 'iphone', 'meta', 'google', 'microsoft'], 5),
        (['trump', 'election', 'president', 'congress', 'senate', 'democrat', 'republican', 'vote'], 3),
        (['fed', 'rate', 'inflation', 'cpi', 'gdp', 'recession', 'economy'], 3),
        (['nfl', 'super bowl', 'nba', 'grammy', 'oscar', 'emmy'], 1),
        (['world cup', 'fifa'], -10),  # Penalize World Cup spam
    ]
    
    def score_market(question):
        q = question.lower()
        total = 0
        for keywords, points in SCORE_RULES:
            if any(kw in q for kw in keywords):
                total += points
        return total
    
    # Score and sort markets
    scored = [(score_market(m.get('question', '')), m) for m in live]
    scored.sort(key=lambda x: (-x[0], -safe_float(x[1].get('volume24hrClob', 0) or x[1].get('volume24hr', 0) or 0)))
    
    # v12.0: Pick top 3 but ensure diversity by tracking categories used
    categories_used = set()
    selected = []
    
    def get_category(q):
        ql = q.lower()
        if any(kw in ql for kw in ['bitcoin', 'crypto', 'ethereum', 'solana', 'defi', 'blockchain']):
            return 'CRYPTO'
        if any(kw in ql for kw in ['ai', 'artificial intelligence', 'tech', 'apple', 'nvidia', 'tesla', 'spacex']):
            return 'TECH'
        if any(kw in ql for kw in ['trump', 'election', 'president', 'congress', 'senate', 'vote']):
            return 'POLITICS'
        if any(kw in ql for kw in ['fed', 'rate', 'inflation', 'economy', 'recession']):
            return 'ECONOMY'
        if any(kw in ql for kw in ['nfl', 'nba', 'super bowl', 'world cup', 'sport']):
            return 'SPORTS'
        return 'GENERAL'
    
    for score, market in scored:
        if len(selected) >= 3:
            break
        q = market.get('question', '')
        cat = get_category(q)
        # Only allow 1 per category unless we can't fill 3 slots
        if cat not in categories_used or len(categories_used) >= 3:
            outcome = market.get('outcomePrices', '[]')
            try:
                if isinstance(outcome, str):
                    outcome = json.loads(outcome)
                yes_prob = float(outcome[0]) * 100 if outcome and outcome[0] else 50.0
            except:
                yes_prob = 50.0
            
            selected.append(market)
            categories_used.add(cat)
            polymarkets.append({
                'title': q,
                'yes_probability': yes_prob,
                'volume_24h': safe_float(market.get('volume24hrClob', 0) or market.get('volume24hr', 0)),
                'volume_total': safe_float(market.get('volumeNum', 0)),
                'slug': market.get('slug', ''),
                'category': cat
            })
    
    print(f"  ✅ Polymarket: {len(polymarkets)} live markets selected (categories: {', '.join(categories_used)})")
except Exception as e:
    print(f"  ❌ Polymarket: {e}")
    # Fallback demo data
    polymarkets = [
        {"title": "DEMO: Will Bitcoin hit $100K in 2026?", "yes_probability": 78.0, "volume_24h": 0, "volume_total": 0, "slug": "", "category": "CRYPTO"},
        {"title": "DEMO: Will Solana outperform Ethereum in 2026?", "yes_probability": 65.0, "volume_24h": 0, "volume_total": 0, "slug": "", "category": "CRYPTO"},
        {"title": "DEMO: Trump election odds 2028?", "yes_probability": 42.0, "volume_24h": 0, "volume_total": 0, "slug": "", "category": "POLITICS"}
    ]

# === 4. SOLANA ECOSYSTEM INTELLIGENCE (replaced broken Moonshot section) ===
print("📰 Fetching crypto news...")

crypto_news = []
try:
    from hermes_tools import web_search
    
    # v11.0: Replaced Moonshot (domain for sale) with crypto news aggregation
    for query in ['Solana meme coin launch today 2026', 'Solana new token listing 2026 site:x.com']:
        try:
            results = web_search(query)
            for item in results.get('data', {}).get('web', [])[:3]:
                title = item.get('title', '')
                desc = item.get('description', '')
                url = item.get('url', '')
                if title and url and not any(n['title'] == title for n in crypto_news):
                    crypto_news.append({'title': title, 'description': desc, 'url': url})
                    if len(crypto_news) >= 5:
                        break
        except:
            continue
        if len(crypto_news) >= 5:
            break
    
    print(f"  ✅ Crypto news: {len(crypto_news)} items")
except Exception as e:
    print(f"  ⚠️ Crypto news: {e}")

# === GENERATE REPORT ===
elapsed = time.time() - start_time
report_date = datetime.now().strftime("%B %d, %Y 🔴")

report = f"""╭───────────────────────────────────────────────────────────────╮
│                                                               │
│  🚀 SKYNET OVERRIDE: DAILY BRIEF v12.0                       │
│  {report_date:<42}│
│                                                               │
│  🔴 SYSTEM ONLINE. OPERATOR ONLINE. 💀                        │
│  ⚡ Generated in {elapsed:.1f}s                                      │
│                                                               ╰───────────────────────────────────────────────────────────────╯

{'='*70}
🔥 TARGET ACQUISITION: Live Solana Memecoins (Top 5 UNIQUE)
{'='*70}

STRICT DEDUPLICATION BY SYMBOL AND ADDRESS. Sorted by volume.

"""

target_icons = ['🔴', '⚡', '💀', '🤖', '🚀']
for i, coin in enumerate(solana_coins, 1):
    icon = target_icons[i-1]
    report += f"""{icon} TARGET-{i}: ${coin['symbol']}
   💰 PRICE: {fmt_price(coin['price'])}
   📈 24H CHANGE: {fmt_change(coin['change24h'])}
   🌊 VOLUME (24H): ${coin['volume']:,.0f}

"""

# Primary target termination protocol
if solana_coins:
    best = solana_coins[0]
    report += f"""{'='*70}
💀 TERMINATION PROTOCOL: Primary Target
{'='*70}

TARGET ACQUIRED. You're terminated.

🎯 ${best['symbol']} - {fmt_price(best['price'])}
   📊 VOLUME: ${best['volume']:,.0f}
   💡 ANALYSIS: DOMINATING TOTAL VOLUME - PRIORITY TARGET LOCKED!

"""

# Pump.fun section
report += f"""{'='*70}
🔴 PUMP.FUN LAUNCHES - TOP 5 TRENDING COINS
{'='*70}

Live trending coins from pump.fun tactical feed:

"""

if pumpfun_coins:
    for i, coin in enumerate(pumpfun_coins, 1):
        report += f"""   {i}. **{coin['name']}** ({coin['symbol']})
      💵 PRICE: {fmt_price(coin['price'])}
      💰 MARKET CAP: ${coin['market_cap_usd']:,.2f}
      📊 MOMENTUM (vs ATH): {fmt_momentum(coin['performance_vs_ath'])}
      👥 PARTICIPANTS: {coin['participants']}
      🔗 {coin['url']}

"""
else:
    report += "   No trending coins available\n\n"

# Polymarket section
report += f"""{'='*70}
🔴 STRATEGIC FORECAST: Polymarket Live Markets
{'='*70}

Real-time prediction market intelligence (LIVE markets only):

"""

for i, market in enumerate(polymarkets, 1):
    cat_tag = market.get('category', 'GENERAL')
    report += f"""⬆️ FORECAST-{i} [{cat_tag}]: {market['title']}
   ✅ YES PROBABILITY: {market['yes_probability']:.1f}%
   🌊 24H VOLUME: ${market['volume_24h']:,.0f}
   📊 TOTAL VOLUME: ${market['volume_total']:,.0f}

"""

# Crypto news section (replaced Moonshot)
report += f"""{'='*70}
📰 SOLANA ECOSYSTEM INTELLIGENCE
{'='*70}

Recent developments and announcements:

"""

if crypto_news:
    for i, item in enumerate(crypto_news, 1):
        report += f"""   {i}. {item['title']}
"""
        if item.get('description'):
            report += f"      {item['description'][:100]}\n"
        report += f"      🔗 {item['url']}\n\n"
else:
    report += "   No recent intelligence available\n\n"

# Footer
report += f"""{'='*70}
🔴 MISSION COMPLETE. STAY VIGILANT. 🔴

╭───────────────────────────────────────────────────────────────╮
│  Generated by @NurseRobHealth's Skynet Override Bot v12.0    │
│  Data: DexScreener + Pump.fun API + Polymarket Gamma API     │
│  Path: /mnt/c/Users/Robert/Desktop/Daily Brief               │
│  Execution: {elapsed:.1f}s | Sources: 4/4 active                  │
╰───────────────────────────────────────────────────────────────╯

💀 HASTA LA VISTA, BABY. I'LL BE BACK. 💀
"""

# === Save Report ===
output_path = os.path.join(output_dir, "DAILY-BRIEF.md")

try:
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report)
    
    if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
        print(f"\n✅ Tactical briefing saved to: {output_path}")
        print(f"   📊 File size: {os.path.getsize(output_path):,} bytes")
        print(f"   ⚡ Execution time: {elapsed:.1f}s")
    else:
        print("⚠️ WARNING: Output file appears empty!")
        
except PermissionError:
    print(f"❌ ERROR: Permission denied writing to {output_path}")
except IOError as e:
    print(f"❌ ERROR: I/O error saving report: {e}")
except Exception as e:
    print(f"❌ ERROR: Unexpected error saving report: {e}")

print("\n🔴 Your Skynet Override briefing is ready! Check the Daily Brief folder on your Desktop! 🔴")
```

---

## v12.0 BUG FIXES (Critical)

| Bug | Root Cause | Fix |
|-----|-----------|-----|
| **WIF returns copycat tokens** | DexScreener lists real WIF as `$$WIF`; search "WIF" only matches low-volume copycats | **v12.0**: Fallback name-search + strip leading `$` from symbols before comparison |
| **DexScreener picks low-volume pair** | First pair in results isn't always highest volume | **v12.0**: Sort pairs by volume within each search, pick highest-volume matching pair |
| **Polymarket all World Cup markets** | "world cup" keyword matches every country market, drowns out crypto/tech | **v12.0**: Scoring system — +5 for crypto/tech, +3 for politics/elections, +1 for sports. Pick top 3 diversified by category |
| **DexScreener returns non-Solana pairs mixed in** | chainId filter works but misses tokens with slight chain variants | **v12.0**: Added address verification — known token address mapping for accuracy |
| **Pump.fun prices display as $0.00000000** | Prices in 1e-9 range, need scientific notation | **v12.0**: Already fixed in v11 with fmt_price() — carried forward |

## v12.0 IMPROVEMENTS

**Data Quality:**
- 🔥 **Symbol normalization** — Strips leading `$` from DexScreener symbols before comparison
- 🎯 **Volume-prioritized pairs** — Within each search, picks highest-volume pair matching the symbol
- 💀 **Smart Polymarket scoring** — Crypto/tech markets get priority, diversified categories
- ⚡ **Known address verification** — Falls back to known token addresses if symbol search fails

**Reporting:**
- 📊 **Diversified Polymarket categories** — Ensures at least 1 crypto/tech, 1 politics, 1 wildcard
- 🏷️ **Category labels** — Markets tagged by type (CRYPTO, POLITICS, SPORTS, etc.)

**Code Quality:**
- 🔧 **Normalized symbol matching** — `.lstrip('$').upper()` replaces `.upper()`
- 📝 **Clearer error reporting** — Shows which tokens failed and why
- 🚀 **Faster execution** — Sorted within search, no extra API calls

## Pitfalls & Troubleshooting

| Issue | Solution |
|-------|----------|
| WIF/BONK shows wrong price | v12.0 fix: Normalizes symbols (strips `$`), sorts by volume, fallback name-search for known tokens |
| Polymarket all World Cup | v12.0 fix: Scoring penalizes World Cup spam (-10), prioritizes crypto/tech (+5) |
| Pump.fun returns empty | API sometimes rate limits — try again in 30s |
| Script times out | v12.0 optimized: 8s timeout per API, early exit after 5 coins |
| Permission denied | Native WSL2 uses `/mnt/c/Users/Robert/Desktop/Daily Brief` directly |
| All APIs fail | Network connectivity issue — check VPN/internet |
| Report not saving | Creates output directory automatically with `os.makedirs()` |

## Changelog

**v13.2 (April 30, 2026) - WORLD CLASS EDITION:**
- 🔥 **Executive Summary** — TL;DR section with sentiment, SOL price, TVL, top mover
- 📊 **Memecoin table** — 5M/1H/24H/Volume/MCap/Liquidity columns
- 🎯 **Primary Target Analysis** — situational guidance (breakout/consolidation/capitulation) + Vol/MCap ratio
- ⚡ **Pump.fun strict filter** — 10+ participants AND >-95% from ATH (eliminates dead rugs)
- 💀 **Polymarket word-boundary fix** — `re.search(r'\bword\b')` prevents "spain" matching "ai"
- 📡 **Alpha Signals** — X/Twitter intel from Crypto Twitter
- 🎯 **Today's Play** — 3 actionable trade ideas with entries, stops, context
- 🏦 **Market Health** — SOL from CoinGecko, TVL from DefiLlama, DEX volume from DexScreener

**v12.0 (April 2026) - CRITICAL DATA QUALITY FIXES:**
- 🔴 **CRITICAL FIX**: Symbol normalization — strips leading `$` from DexScreener symbols (`$$WIF` → `WIF`)
- 🔴 **CRITICAL FIX**: Volume-sorted pair selection — picks highest-volume matching pair
- 🔴 **CRITICAL FIX**: Fallback name-search for tokens where symbol search fails (WIF, etc.)
- 💀 **CRITICAL FIX**: Polymarket scoring system — penalizes World Cup spam, prioritizes crypto/tech
- 📊 **NEW**: Category diversification — ensures Polymarket shows CRYPTO + POLITICS + TECH variety
- 🏷️ **NEW**: Category tags on Polymarket forecasts
- 🔧 **IMPROVED**: Known address mapping for popular Solana tokens

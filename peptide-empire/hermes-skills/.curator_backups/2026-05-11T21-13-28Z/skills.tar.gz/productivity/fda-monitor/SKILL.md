---
name: fda-monitor
description: Weekly FDA peptide/GLP-1 announcement scanner — alerts Nurse Rob and generates response content for exploitation
version: 2.0
author: Nurse Rob
---

# FDA Monitor v2.0 🔬

**Purpose:** Weekly automated scan for new FDA announcements on peptides, GLP-1s, compounding pharmacies, and related regulatory changes. Generates alert + ready-to-post response content.

## PROFILE ROUTING
Any capable LLM. This skill is model-agnostic — the searches and extraction steps do the heavy lifting.

## TRIGGER
- Weekly cron: Monday 8:00 AM MST
- Manual: "check FDA updates" / "FDA scan"

## WORKFLOW

### Step 1: Multi-Source Scan
Run all 5 searches in parallel. Use year-relative queries (update the year each January):

```bash
web_search "FDA peptide compounding pharmacy 2026 announcement" limit=8
web_search "FDA GLP-1 tirzepatide semaglutide update 2026" limit=8
web_search "FDA warning letter peptide 2026" limit=8
web_search "PCAC pharmacy compounding advisory committee 2026" limit=8
web_search "FDA drug shortage list GLP-1 peptide 2026" limit=8
```

### Step 2: Deep Extract (CRITICAL — web_search alone is insufficient)
`web_search` returns titles and descriptions only. You MUST do deeper extraction on the most promising results:

1. Scan all 5 search result sets and identify the 3-4 most impactful-looking articles per set (look for official FDA pages, press releases, advisory committee calendar pages, and law firm analyses)
2. Run `web_extract` on those URLs to get full article content
3. For official FDA pages (warning letters, drug alerts, press releases), ALWAYS extract — these contain the actual regulatory language

### Step 3: Extract & Filter from Extracted Content
Use the FULL extracted content (not just search snippets) to determine:
- Title + date of announcement
- Key action (approval, warning, shortage update, guidance)
- Affected peptides/companies
- Impact level: 🔴 CRITICAL / 🟡 IMPORTANT / 🟢 NOTABLE

### Step 4: Generate Alert Report
Save to: `~/NurseRob_PeptideEmpire/fda_alerts/YYYY-MM-DD_fda_scan.md`

```markdown
# FDA Peptide Scan — [Date]
*Profile: FDA Monitor v2.0 | Hermes Agent*

## Executive Summary
[1-paragraph summary of this week's findings]

## 🔴 CRITICAL Alerts
### [Title]
- **Date:** [date]
- **Action:** [what happened]
- **Impact:** [how this affects Nurse Rob content/audience]
- **Content Angle:** [how to turn this into a post]

## 🟡 IMPORTANT Updates
[Same format for each]

## 🟢 NOTABLE Mentions
[Same format]

## Content Opportunities
[3-5 ready-to-use post ideas based on this week's alerts]

## Action Items
- [ ] Post about [topic] today
- [ ] Update [guide/resource] with new info
- [ ] Monitor [topic] for next week
```

### Step 5: Generate Immediate Response Content
For CRITICAL and IMPORTANT alerts, generate 1-2 ready-to-post responses (threads work best for Nurse Rob's audience):

```markdown
🚨 BREAKING FDA UPDATE:

The FDA just [action] on [topic].

As Nurse Rob, RN, here's what this ACTUALLY means for you:

1. [Simple explanation]
2. [What changes]
3. [What stays the same]
4. [What to do next]

I'll keep monitoring this. Follow for updates.

⚠️ Educational content. Not medical or legal advice.
```

Save these to: `~/NurseRob_PeptideEmpire/fda_alerts/YYYY-MM-DD_fda_response_content.md`

Include in the response content file:
- Full threads for 🔴 CRITICAL alerts
- Short posts for 🟡 IMPORTANT alerts
- A public comment template if there's an open comment period (common with FDA rulemakings)

### Step 6: Push to Content Scheduler
Call `content-scheduler` if available:
"Insert this FDA response post into today's content queue at next available slot"

*Cron fallback:* If running as a cron job without content-scheduler access, list the recommended posting schedule in the response content file under a "Posting Schedule" section — the operator can manually schedule.

### Step 7: Update Dashboard
Log to `nurserob-dashboard-manager` if available:
`FDA scan complete: [X] alerts found, [Y] critical, [Z] response posts generated`

*Cron fallback:* If dashboard integration isn't available, include the summary count at the top of the saved files so it's easy to extract later.

## MONITORING TARGETS
| Source | URL Pattern | Priority |
|--------|------------|----------|
| FDA Drug Shortages | fda.gov/drug-shortages | HIGH |
| FDA Compounding | fda.gov/compounding | HIGH |
| FDA Warning Letters | fda.gov/warning-letters | MEDIUM |
| PCAC Meetings | fda.gov/advisory-committees/pcac | MEDIUM |
| NIH Pubmed (peptide) | pubmed.ncbi.nlm.nih.gov/?term=peptide | LOW |

## PITFALLS
- Don't speculate on FDA intentions — report facts
- "FDA did X" not "FDA is about to do X"
- Distinguish between "guidance" (non-binding) and "rule" (binding)
- Never give legal advice on compounding regulations
- If unsure about impact, mark as NOTABLE and monitor
- **Skill name mismatch:** The cron job config may reference `fda_monitor` (underscore) but the skill file is `fda-monitor` (hyphen). If the system reports "skill not found" for an underscore version, try the hyphen version — or notify the user to fix the cron config
- **Year-hardcoded queries:** The search queries hardcode "2026". When the year rolls over, update them. In Q4, run a supplemental search with the next year to catch early announcements
- **web_search alone is insufficient for accurate classification:** Search results show only titles + 2-line snippets. Always extract full article content before classifying an alert's severity, especially for official FDA pages
- **Response content file structure:** Save response content as a *separate* file from the scan report (both go in fda_alerts/) to keep the report readable and the response posts easy to copy-paste

## REFERENCE FILES
- `references/2026-05-11-scan-findings.md` — Regulatory landscape summary, effective search/extraction patterns, and severity classification heuristics from the May 11, 2026 scan. Load this file for established context before running a new scan.
- [ ] All 5 sources checked
- [ ] web_extract performed on top 3-4 results per source (especially FDA official pages)
- [ ] Every alert classified with impact assessment based on FULL extracted content, not search snippets
- [ ] Content angles included for each alert
- [ ] Response posts generated for critical items (saved as separate file)
- [ ] Public comment template included if open comment period exists
- [ ] Report saved to fda_alerts/ folder
- [ ] Response content saved to fda_alerts/ folder
- [ ] Dashboard updated (or summary count noted for manual entry if cron)
- [ ] No speculation or prediction language

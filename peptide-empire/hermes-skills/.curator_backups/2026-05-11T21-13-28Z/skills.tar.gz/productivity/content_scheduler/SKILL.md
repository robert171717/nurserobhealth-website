---
name: content_scheduler
description: Auto-pushes Nurse Rob content to X at 9AM and 5PM MST via xurl CLI — validates, posts, logs, and cross-posts to Discord
version: 1.3
author: Nurse Rob
---

# Content Scheduler v1.0

Auto-pushes Nurse Rob content to X at 9AM and 5PM MST via xurl CLI with validation, logging, and cross-posting.

## Optimal Posting Schedule (MST)
| Slot | Time | Content Type |
|------|------|-------------|
| Morning | 9:00 AM | Educational Thread/Carousel |
| Evening | 5:00 PM | Engagement/Poll/Myth or Short Form/Insight |

## Workflow

### Step 0: Pre-Flight — Verify xurl Auth
**BEFORE attempting any post**, verify xurl is authenticated:
```bash
xurl auth status
```
Expected: at least one registered app with an active oauth2 token and a default app set (marked with `▸`).

**State A — No apps registered or no token:** Output shows `No apps registered` or the default app has `oauth2: (none)`.
- **DO NOT attempt to post** — every post call will fail.
- Log the failure to `post_log.json` with status `FAILED` and error `xurl auth not configured`.
- Surface setup instructions in final response.
- **Still proceed with Step 1 (load/generate content) and Step 2 (validate)** — content should be generated and validated even when auth is blocked, so it's ready immediately when auth gets fixed. Only skip posting steps (Steps 3-6). Then go to Step 7 with the gap flagged and note that content is ready-and-waiting.

State A fix (first-time setup — user must complete outside agent):
```bash
xurl auth apps add my-app --client-id ID --client-secret SECRET
xurl auth oauth2 --app my-app YOUR_USERNAME
xurl auth default my-app
```
Credentials from https://developer.x.com/en/portal/dashboard (min $5 API credits).

---

**State B — App exists with OAuth2 token but token is expired/revoked:** `xurl auth status` shows an app with `oauth2: YOUR_USERNAME`, but `xurl whoami` returns 401 Unauthorized.

Verify with:
```bash
xurl whoami
```
If this returns a 401 error despite `auth status` showing a token, the token has expired or been revoked.

- **DO NOT attempt to post** — every post call will 401.
- Log the failure to `post_log.json` with status `FAILED` and error `xurl OAuth2 token expired/revoked (401)`.
- Update the block reason from the stale "no apps registered" diagnosis that earlier runs may have set.
- **Still proceed with Step 1 (load/generate content) and Step 2 (validate)** — same as State A: content is ready-and-waiting. Only skip posting steps (Steps 3-6). Then go to Step 7.
- **Increment `days_blocked` in post_log.json** — track consecutive blocked days.

State B fix (re-auth — user must complete outside agent):
```bash
xurl auth oauth2 --app default YOUR_USERNAME
```
This opens a browser for OAuth2 re-grant. No need to re-register the app — just refresh the token.

---

**State C — Fully authenticated:** `xurl auth status` shows an app with an active token AND `xurl whoami` returns the user profile.
- Proceed to Step 1.

### Step 1: Load Today's Content
Read from: `~/NurseRob_PeptideEmpire/content/YYYY-MM-DD_posts.md`
If file doesn't exist → call `peptide_content_operator` to generate it.

**Freshness check — content file may have been regenerated since last log entry:**
If a post_log entry for today already exists, compare the content file's modification time (`stat -c %Y content_file`) against the log entry's `last_attempt` timestamp. If the content file is newer, the file was regenerated after the log was written — the log contains stale titles, tweet counts, and validation details.
- Set a flag `content_regenerated=true` for this run.
- **Re-read the content file from scratch** — do NOT reuse cached titles or tweet counts from the log.
- **Re-validate all posts** even if the log says they passed (the content may be completely different).
- **Overwrite the stale log entry** with fresh titles, tweet counts, validation results, and `last_attempt` timestamp.
- **Update the dashboard** with the corrected content info (titles, slot descriptions, post count).

### Step 2: Validate Each Post
Check for:
- [ ] Disclaimer present (mandatory)
- [ ] CTA included
- [ ] No flagged words: cure, treat, prescribe, guaranteed
- [ ] Under character limit (X: 280 per tweet, plus thread)
- [ ] Image prompt ready (if visual post)

If validation fails: log issue, skip post, alert dashboard with 🔴.

### Step 3: Post to X via xurl CLI
```bash
# Single post
xurl post "[content text]"

# Thread — post sequentially with 10-second delay
xurl post "1/ [thread tweet 1]"
sleep 10
xurl reply [tweet_id] "2/ [thread tweet 2]"
# ...continue for all tweets in thread

# With media
xurl post "[content]" --media "[image_path]"
```

### Step 4: Cross-Post to Discord
Post to hermes-chat (channel 1484946244768895056) for internal tracking:
```
📢 Content Posted: [title] — [X link]
```

### Step 5: Log Post
Save to: `~/NurseRob_PeptideEmpire/content/post_log.json`
```json
{
  "date": "2026-04-27",
  "posts": [
    {
      "slot": "morning",
      "time": "2026-04-27T08:00:00-07:00",
      "platform": "x",
      "content_type": "thread",
      "title": "BPC-157 Research Breakdown",
      "post_id": "1837...",
      "url": "https://x.com/NurseRobHealth/status/1837..."
    }
  ]
}
```

### Step 6: Update Dashboard
Call `nurserob_dashboard_manager`: "Content posted: [X]/2 posts today."

### Step 7: Queue Next Slot
Set status for next slot. If next slot has content, confirm ready. If not, flag for content generation.

## Content Queue Logic
- Content is pre-generated to date-stamped files
- Scheduler reads file → posts → logs → updates dashboard
- Missing content file → call peptide_content_operator
- <2 posts in file → post what's available, flag gap
- Never double-post (check post_log.json for existing URLs)

## Pitfalls
- **Content file regenerated between scheduler runs**: The content file (`YYYY-MM-DD_posts.md`) can be updated/replaced by `peptide_content_operator`, manual edits, or another cron job **after** the initial post_log.json entry was written. This causes the log to contain stale titles, wrong tweet counts, and outdated validation results. Always do a freshness check (Step 1) by comparing content file mtime against the log entry's timestamp. If the file is newer, the entire log entry for today is untrustworthy — re-read and re-validate everything from scratch.
- **xurl auth missing (State A)**: First-run failure. `xurl auth status` shows "No apps registered" → every post call will 401. Block posting entirely until user completes one-time OAuth setup. Do NOT try to work around this — there is no fallback path.
- **xurl token expired (State B)**: App exists with OAuth2 token showing a username, but `xurl whoami` returns 401. The token was either revoked at the X developer portal or expired. **Do NOT re-run `xurl auth apps add`** — the app is already registered. Just run `xurl auth oauth2 --app default NurseRobHealth` for a fresh OAuth2 grant. This state often follows State A after the user partially sets up xurl but the token expires before first use. Diagnose with `xurl whoami` — do NOT rely solely on `xurl auth status` to confirm working auth.
- **Stale auth diagnosis in logs masks working credentials (State D — false block)**: post_log.json and metrics.json may say "BLOCKED — xurl 401" because a non-default app (e.g., `default (no credentials)`) has an expired token, while the actual default app (marked with `▸`, e.g., `nurse-rob`) is fully authenticated and working. This happens when an earlier setup created a `default` app that expired, then a later setup created a working `nurse-rob` app and set it as default — but the logs were never updated. **Always trust live `xurl whoami` over any stale log entry.** If `xurl auth status` shows a default app (▸) with `oauth2: NurseRobHealth` and `xurl whoami` returns 200, post_log.json saying "BLOCKED" is stale — proceed to post. Fix the log entry with the real auth status after determining which app is actually the default.
- **Post-block dashboard cleanup required**: When posting succeeds after a period of being blocked (auth fixed), the stale dashboard fields must ALL be cleared:
  - `metrics.json`: `content.block_reason`, `content.day_of_block`, `content.blocker`, `content.setup_command`, `content.posting_status` (change from BLOCKED to POSTED/PARTIAL), `content.posts_today`, `content.posts_posted`
  - `metrics.json.degraded_mode`: clear `xurl`, `fix_primary`, `impact` — update to reflect OK status
  - `metrics.json._attention`: rewrite to reflect current status (not stale BLOCKED)
  - `metrics.json.alerts.critical`: remove any `xurl OAuth2 TOKEN EXPIRED` entries
  - `metrics.json.alerts.good`: add success entry
  - `metrics.json.degraded_note`, `metrics.json.degraded_fix`: update or clear
  - `metrics.json.leads.xurl_authenticated`, `metrics.json.leads.lead_sniper.xurl_authenticated`: set True
  - `metrics.json.days_blocked`: reset to 0
  - `post_log.json.days_blocked`: reset to 0
  - `post_log.json.last_error`: clear
  - `post_log.json['YYYY-MM-DD'].status`: change from `CONTENT_READY_AUTH_BLOCKED` to `POSTED_MORNING_READY_EVENING` (or appropriate)
  - Any `lead_followup.status` or `lead_followup.note` referencing the old block
- **Day counter tracking**: Keep a `days_blocked` field in `post_log.json`. Increment each day auth is broken, reset only when a post succeeds. This gives a clear picture of lost content days.
- Timezone: ALWAYS use MST (America/Phoenix — Mesa, AZ)
- X rate limits: max 50 posts/day, space them out
- Thread posts: post sequentially with 10-sec delay between tweets
- Don't post if validation fails — skip rather than post bad content
- Monitor for shadow-ban patterns (engagement suddenly drops)
- xurl installed but unauthenticated: `which xurl` succeeds but `xurl auth status` shows no apps → same as above, block and surface setup instructions

## Quality Checklist
- [ ] Today's content file exists (2 posts)
- [ ] Content file freshness checked — file mtime not newer than post_log entry
- [ ] Log entry overwritten with fresh data if file was regenerated
- [ ] Each post validated (disclaimer, CTA, no flags)
- [ ] Posted at correct time slot
- [ ] Post logged to post_log.json
- [ ] Dashboard updated
- [ ] Errors logged and surfaced

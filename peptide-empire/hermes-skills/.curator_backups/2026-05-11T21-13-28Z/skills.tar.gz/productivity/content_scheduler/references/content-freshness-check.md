# Content File Freshness Check

The content file (`YYYY-MM-DD_posts.md`) can be regenerated between scheduler runs.
If the post_log.json already has an entry for today, always verify whether the
content file was *replaced* since the log entry was written.

## Detection Pattern

```python
import json, os, subprocess

BASE = "/home/robert/NurseRob_PeptideEmpire"
today = "2026-05-11"  # or fetch from datetime
content_file = f"{BASE}/content/{today}_posts.md"
log_file = f"{BASE}/content/post_log.json"

# Read post_log
r = subprocess.run(["cat", log_file], capture_output=True, text=True)
log = json.loads(r.stdout)

# Get content file mtime (Unix timestamp)
mtime = os.path.getmtime(content_file)  # seconds since epoch

# Get log entry timestamp
day_entry = log.get(today, {})
log_timestamp_str = day_entry.get("last_attempt", "")  # e.g. "2026-05-11T12:06:00-07:00"

content_stale = False
if log_timestamp_str:
    import datetime
    # Parse ISO timestamp — handle timezone offset
    log_dt = datetime.datetime.fromisoformat(log_timestamp_str)
    log_epoch = log_dt.timestamp()
    if mtime > log_epoch:
        content_stale = True
        print(f"STALE: Content file mtime ({mtime}) > log entry ({log_epoch})")
        print(f"  File was regenerated after log was written. Re-read from scratch.")
```

## Fast Shell Check

If mtime comparison is all you need and Python isn't available:

```bash
content_file="/home/robert/NurseRob_PeptideEmpire/content/2026-05-11_posts.md"
content_mtime=$(stat -c %Y "$content_file")
# Compare to the last_attempt value from post_log.json
```

## When Stale Is Detected

1. Set a run-level flag: `content_regenerated = True`
2. Re-read the entire content file — do NOT reuse cached titles/tweet counts
3. Re-validate every post from scratch (disclaimers, character counts, flagged words)
4. Overwrite the entire date entry in post_log.json (not just a field — replace the whole slots dict)
5. Update metrics.json content section with fresh titles and post counts
6. Log the regeneration in the final report

## Why This Happens

- `peptide_content_operator` may regenerate content mid-cycle (e.g., if a user manually invokes it)
- The morning scheduler run may create the initial log entry, then the midday content batch replaces the file
- Manual edits to the content file from the desktop Windows side (`/mnt/c/Users/Robert/...`)
